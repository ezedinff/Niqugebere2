<?php

namespace App\Http\Controllers;

use App\PathWoreda;
use Illuminate\Http\Request;

class PathWoredaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PathWoreda  $pathWoreda
     * @return \Illuminate\Http\Response
     */
    public function show(PathWoreda $pathWoreda)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PathWoreda  $pathWoreda
     * @return \Illuminate\Http\Response
     */
    public function edit(PathWoreda $pathWoreda)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PathWoreda  $pathWoreda
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PathWoreda $pathWoreda)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PathWoreda  $pathWoreda
     * @return \Illuminate\Http\Response
     */
    public function destroy(PathWoreda $pathWoreda)
    {
        //
    }
}
