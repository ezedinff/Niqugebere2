@extends('admin.layouts.app')
@section('content')
    <div class="row">
        {!! $form !!}
    </div>
@endsection