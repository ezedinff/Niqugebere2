@extends('supplier.layouts.app')
@section('content')
    <div class="row"></div>
@endsection