<?php

namespace App\Http\Controllers;

use App\ProductSubCategoryTranslation;
use Illuminate\Http\Request;

class ProductSubCategoryTranslationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProductSubCategoryTranslation  $productSubCategoryTranslation
     * @return \Illuminate\Http\Response
     */
    public function show(ProductSubCategoryTranslation $productSubCategoryTranslation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProductSubCategoryTranslation  $productSubCategoryTranslation
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductSubCategoryTranslation $productSubCategoryTranslation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProductSubCategoryTranslation  $productSubCategoryTranslation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductSubCategoryTranslation $productSubCategoryTranslation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProductSubCategoryTranslation  $productSubCategoryTranslation
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductSubCategoryTranslation $productSubCategoryTranslation)
    {
        //
    }
}
